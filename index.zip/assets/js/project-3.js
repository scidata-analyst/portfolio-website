// PROJECT 3 - Auction Car Platform
(function() {
    'use strict';

    // LOADER
    let loaderProgress = 0;
    const loaderNum = document.querySelector('[data-loader-num]');
    const loaderFill = document.querySelector('.loader-fill');
    const loader = document.querySelector('.loader');

    function updateLoader() {
        loaderProgress += Math.random() * 15;
        if (loaderProgress >= 100) {
            loaderProgress = 100;
            if (loaderNum) loaderNum.textContent = '100';
            if (loaderFill) loaderFill.style.width = '100%';
            setTimeout(() => {
                if (loader) loader.classList.add('loaded');
                revealHero();
            }, 500);
        } else {
            if (loaderNum) loaderNum.textContent = Math.floor(loaderProgress);
            if (loaderFill) loaderFill.style.width = loaderProgress + '%';
            setTimeout(updateLoader, 100 + Math.random() * 200);
        }
    }

    // CUSTOM CURSOR
    const cursor = document.querySelector('[data-cursor]');
    const cursorDot = cursor?.querySelector('.cursor-dot');
    const cursorRing = cursor?.querySelector('.cursor-ring');
    const cursorLabel = cursor?.querySelector('.cursor-label');
    let mouseX = 0, mouseY = 0;
    let ringX = 0, ringY = 0;

    document.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
        if (cursorDot) {
            cursorDot.style.left = mouseX + 'px';
            cursorDot.style.top = mouseY + 'px';
        }
    });

    function animateRing() {
        ringX += (mouseX - ringX) * 0.15;
        ringY += (mouseY - ringY) * 0.15;
        if (cursorRing) {
            cursorRing.style.left = ringX + 'px';
            cursorRing.style.top = ringY + 'px';
        }
        requestAnimationFrame(animateRing);
    }
    animateRing();

    document.querySelectorAll('[data-magnetic], a, button').forEach(el => {
        el.addEventListener('mouseenter', () => {
            if (cursorRing) { cursorRing.style.width = '60px'; cursorRing.style.height = '60px'; }
            if (cursorLabel) cursorLabel.style.opacity = '1';
        });
        el.addEventListener('mouseleave', () => {
            if (cursorRing) { cursorRing.style.width = '44px'; cursorRing.style.height = '44px'; }
            if (cursorLabel) cursorLabel.style.opacity = '0';
        });
    });

    // HERO REVEAL
    function revealHero() {
        document.querySelectorAll('.p-title-word').forEach((el, i) => {
            setTimeout(() => el.classList.add('revealed'), i * 120);
        });
        setTimeout(() => {
            document.querySelectorAll('.p-hero-desc, .p-hero-metrics').forEach(el => el.classList.add('revealed'));
        }, 600);
    }

    // SCROLL REVEAL
    const revealElements = document.querySelectorAll('[data-reveal], [data-feature], [data-visual]');

    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('revealed', 'active');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });

        revealElements.forEach(el => observer.observe(el));
    }

    // MAGNETIC
    document.querySelectorAll('[data-magnetic]').forEach(el => {
        el.addEventListener('mousemove', (e) => {
            const rect = el.getBoundingClientRect();
            const x = e.clientX - rect.left - rect.width / 2;
            const y = e.clientY - rect.top - rect.height / 2;
            el.style.transform = `translate(${x * 0.2}px, ${y * 0.2}px)`;
        });
        el.addEventListener('mouseleave', () => {
            el.style.transform = 'translate(0, 0)';
        });
    });

    // BID COUNTER ANIMATION
    const bidAmount = document.querySelector('[data-bid-amount]');
    if (bidAmount) {
        let currentBid = 42500;
        setInterval(() => {
            if (Math.random() > 0.7) {
                currentBid += 500;
                bidAmount.textContent = '$' + currentBid.toLocaleString();
            }
        }, 3000);
    }

    // GSAP
    if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
        gsap.registerPlugin(ScrollTrigger);

        const auctionVisual = document.querySelector('.p-auction-mockup');
        if (auctionVisual) {
            gsap.fromTo(auctionVisual, { opacity: 0, y: 60 }, {
                opacity: 1, y: 0, duration: 1, ease: 'power3.out',
                scrollTrigger: { trigger: '.p-auction', start: 'top 70%' }
            });
        }
    }

    setTimeout(updateLoader, 300);

})();
